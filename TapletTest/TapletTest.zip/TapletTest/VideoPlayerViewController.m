//
//  VideoPlayerViewController.m
//  TapletTest
//
//  Created by Brian Wong on 10/2/15.
//  Copyright © 2015 Brian Wong. All rights reserved.
//

#import "VideoPlayerViewController.h"
#import "PhotosCollectionViewController.h"


@interface VideoPlayerViewController ()

@property (weak, nonatomic) IBOutlet UIView *mainView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *playButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *pauseButton;
@property (nonatomic,retain) AVPlayer *videoPlayer;
@property (weak, nonatomic) IBOutlet UIToolbar *mToolBar;
@property (strong, nonatomic) UITapGestureRecognizer *gestureRecognizer;
@property (strong, nonatomic) UITapGestureRecognizer *playPauseRecognizer;
@property (strong,nonatomic) UIView *flashView;
@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, strong) NSMutableArray *imageArray;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *snapshotsButton;
@property (weak, nonatomic) IBOutlet JSVideoScrubber *videoScrubber;


@end

@implementation VideoPlayerViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpPlayer];
    [self setUpScrubber];
    self.gestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenShot)];
    self.gestureRecognizer.numberOfTapsRequired = 1;
    [self.playerView addGestureRecognizer:self.gestureRecognizer];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.imageArray = [[NSMutableArray alloc]init];
    self.snapshotsButton.enabled = NO;
}

-(void)viewWillDisappear:(BOOL)animated{
    self.videoPlayer = nil;
    self.imageArray = nil;
}

-(void)setUpPlayer{
    self.videoPlayer = [[AVPlayer alloc]initWithURL:self.videoURL];
    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.videoPlayer];
    playerLayer.frame = self.view.bounds;
    [self.playerView.layer addSublayer:playerLayer];
    [self.videoPlayer play];
}

-(void)setUpScrubber{
    
    __weak VideoPlayerViewController *ref = self;
    
    
    AVURLAsset* asset = nil;
    
    asset = [AVURLAsset assetWithURL:self.videoURL];
    
    
    NSArray *keys = [NSArray arrayWithObjects:@"tracks", @"duration", nil];
    [asset loadValuesAsynchronouslyForKeys:keys completionHandler:^(void) {
        
        //If you want to display duration
//        ref.duration.text = @"Duration: N/A";
//        ref.offset.text = @"Offset: N/A";
        
        [ref.videoScrubber setupControlWithAVAsset:asset];
        
        double total = CMTimeGetSeconds(ref.videoScrubber.duration);
        
        //In case duration time is needed
        int min = (int)total / 60;
        int seconds = (int)total % 60;
        
        
       [ref.videoScrubber addTarget:self action:@selector(updateOffset:) forControlEvents:UIControlEventValueChanged];
    
    }];
}

//Updates video based on marker location(scrubbing)
-(void)updateOffset:(JSVideoScrubber*) videoScrubber{
    float offsetTime = (float)self.videoScrubber.offset;
    
    CMTime currentTime = CMTimeMakeWithSeconds(offsetTime, NSEC_PER_SEC);
    
    if(self.videoPlayer.status == AVPlayerStatusReadyToPlay && self.videoPlayer.currentItem.status == AVPlayerStatusReadyToPlay){
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.videoPlayer.currentItem seekToTime:currentTime toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero completionHandler:^(BOOL finished) {
                [self.videoPlayer play];
            }];
        });
    }
}



- (IBAction)playButtonPressed:(id)sender {
    if(self.videoPlayer.rate == 0.0){
        [self.videoPlayer play];
        
    }
}

- (IBAction)pauseButtonPressed:(id)sender {
    if(self.videoPlayer.rate == 1.0){
        [self.videoPlayer pause];
    }
}

- (IBAction)cancelButtonPressed:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)playPause{
    if(self.videoPlayer.rate == 1.0){
        [self.videoPlayer pause];
    }else{
        [self.videoPlayer play];
    }
}


-(void)screenShot{
    self.snapshotsButton.enabled = YES;
    [self mimicScreenShotFlash];
    [self screenshotFromPlayer:self.videoPlayer];
}

- (IBAction)viewScreensots:(id)sender {
    [self performSegueWithIdentifier:@"showScreenshots" sender:self];
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier]isEqualToString:@"showScreenshots"]){
        PhotosCollectionViewController *photosVC = (PhotosCollectionViewController*) segue.destinationViewController;
        photosVC.imageArray = [NSArray arrayWithArray:self.imageArray];
    }
}


#pragma mark - Helper methods
-(void)mimicScreenShotFlash{
    
    self.flashView = [[UIView alloc]initWithFrame:self.view.frame];
    self.flashView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.flashView];
    
    [UIView animateWithDuration:1.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.flashView.alpha = 0.0;
        AudioServicesPlaySystemSound(1108);
    } completion:^(BOOL finished) {
        [self.flashView removeFromSuperview];
    }];
    
}

- (UIImage *)screenshotFromPlayer:(AVPlayer *)player{
    
    CMTime actualTime;
    NSError *error;
    
    AVAssetImageGenerator *generator = [[AVAssetImageGenerator alloc] initWithAsset:player.currentItem.asset];
    
    //If a specific size is needed, add to function declaration
    //generator.maximumSize = maxSize;
    
    generator.appliesPreferredTrackTransform = YES; //To make picture vertical
    CGImageRef cgIm = [generator copyCGImageAtTime:player.currentTime
                                        actualTime:&actualTime
                                             error:&error];
    UIImage *image = [UIImage imageWithCGImage:cgIm];
    CFRelease(cgIm);
    
    if (nil != error) {
        NSLog(@"Error making screenshot: %@", [error localizedDescription]);
        NSLog(@"Actual screenshot time: %f Requested screenshot time: %f", CMTimeGetSeconds(actualTime),
              CMTimeGetSeconds(self.videoPlayer.currentTime));
        return nil;
    }
    
    [self.imageArray addObject:image];
    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    return image;
}

@end
