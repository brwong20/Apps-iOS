//
//  JSAssetDefines.h
//  JSVideoScrubber
//
//  Created by jaminschubert on 9/8/13.
//  Copyright (c) 2013 jaminschubert. All rights reserved.
//

#define kJSFrameInset 7.0f
#define kJSMarkerYOffset 2.0f
#define kJSImageBorder 3.5f
#define kJSImageDivider 2.0f


